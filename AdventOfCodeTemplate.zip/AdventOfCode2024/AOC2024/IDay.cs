﻿namespace AOC2024
{
    public interface IDay
    {
        public void Start();
    }
}